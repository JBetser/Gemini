"Tests for twistd.mail"
